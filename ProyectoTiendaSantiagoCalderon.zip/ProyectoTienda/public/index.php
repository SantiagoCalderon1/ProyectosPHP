<?php include '../app/views/layouts/cabecera.php'; ?>

<main>
    <?php
    include '../app/views/layouts/formConfiguracion.php';
    ?>
</main>

<?php include '../app/views/layouts/footer.php'; ?>