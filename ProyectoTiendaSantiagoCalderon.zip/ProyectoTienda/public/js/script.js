function enviarFormulario(formId) {
  document.getElementById(formId).submit();
}