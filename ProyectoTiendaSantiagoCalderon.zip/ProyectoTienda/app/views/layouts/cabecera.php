
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Mini APP-WEB'; ?></title>
    <link rel="stylesheet" href="/ProyectoTienda/public/css/style.css"> <!-- Archivo CSS -->
</head>

<body>
    <header>
        <h1><?php echo $titleHeader ?? 'Proyecto de Mini Aplicación Web - PHP'; ?></h1>
    </header>