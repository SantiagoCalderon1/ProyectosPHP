<footer>
    <p>&copy; <?php echo date("Y"); ?> Mini APP-WEB. Todos los derechos reservados.</p>
</footer>
</body>

</html>