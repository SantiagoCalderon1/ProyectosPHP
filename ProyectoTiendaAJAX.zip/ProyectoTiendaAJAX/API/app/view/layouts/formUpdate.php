<div class="formBox">
    <h2>Actualizando Usuario <span id="spanUserId"></span></h2>
    <form action="" id="formUpdate">
        <label for="nombre">Nombre: </label>
        <input type="text" id="nombre" name="nombre">
        <br>
        <label for="apellidos">Apellidos: </label>
        <input type="text" id="apellidos" name="apellidos">
        <br>
        <button onclick="submit()">Aceptar</button>
        <button onclick="submit()">Calcelar</button>
    </form>
</div>