<div class="formBox">
    <h2>Creando Usuario</h2>
    <form action="" id="formInsert">
        <label for="id">ID: </label>
        <input type="text" id="id" name="id" placeholder="El id es automartico" disabled>
        <label for="nombre">Nombre: </label>
        <input type="text" id="nombre" name="nombre">
        <br>
        <label for="apellidos">Apellidos: </label>
        <input type="text" id="apellidos" name="apellidos">
        <br>
        <button onclick="submit()">Aceptar</button>
        <button onclick="submit()">Calcelar</button>
    </form>
</div>